java -jar rsc.jar RSCEmulator
